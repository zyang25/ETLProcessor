'use strict';

const Mongo = require('./MongoConfig.js');

class OPSV{

    constructor(dbInstance) {

		this.etlRoot = 'D:/UPSData/pfs/fdc/log/';
		this.dbInstance = dbInstance;
	}

    
}